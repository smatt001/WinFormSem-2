﻿namespace ClassMateriW14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_Team = new System.Windows.Forms.ComboBox();
            this.dgv_team = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.Minute = new System.Windows.Forms.Label();
            this.tb_Minute = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_team)).BeginInit();
            this.SuspendLayout();
            // 
            // cb_Team
            // 
            this.cb_Team.FormattingEnabled = true;
            this.cb_Team.Location = new System.Drawing.Point(152, 28);
            this.cb_Team.Name = "cb_Team";
            this.cb_Team.Size = new System.Drawing.Size(243, 33);
            this.cb_Team.TabIndex = 4;
            this.cb_Team.SelectedIndexChanged += new System.EventHandler(this.cb_Team_SelectedIndexChanged);
            // 
            // dgv_team
            // 
            this.dgv_team.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_team.Location = new System.Drawing.Point(44, 224);
            this.dgv_team.Name = "dgv_team";
            this.dgv_team.RowHeadersWidth = 82;
            this.dgv_team.RowTemplate.Height = 33;
            this.dgv_team.Size = new System.Drawing.Size(1905, 762);
            this.dgv_team.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(80, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "Team";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "Player";
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(152, 77);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(243, 33);
            this.cb_player.TabIndex = 7;
            this.cb_player.SelectedIndexChanged += new System.EventHandler(this.cb_player_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(80, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 25);
            this.label3.TabIndex = 10;
            this.label3.Text = "Type";
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(152, 126);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(243, 33);
            this.cb_type.TabIndex = 9;
            // 
            // Minute
            // 
            this.Minute.AutoSize = true;
            this.Minute.Location = new System.Drawing.Point(451, 31);
            this.Minute.Name = "Minute";
            this.Minute.Size = new System.Drawing.Size(77, 25);
            this.Minute.TabIndex = 11;
            this.Minute.Text = "Minute";
            // 
            // tb_Minute
            // 
            this.tb_Minute.Location = new System.Drawing.Point(535, 28);
            this.tb_Minute.Name = "tb_Minute";
            this.tb_Minute.Size = new System.Drawing.Size(184, 31);
            this.tb_Minute.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1985, 1015);
            this.Controls.Add(this.tb_Minute);
            this.Controls.Add(this.Minute);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv_team);
            this.Controls.Add(this.cb_Team);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_team)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cb_Team;
        private System.Windows.Forms.DataGridView dgv_team;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Label Minute;
        private System.Windows.Forms.TextBox tb_Minute;
    }
}

