﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ClassMateriW14
{
    public partial class Form1 : Form
    {
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt =new DataTable();
        DataTable dt2 = new DataTable();
        DataTable dt3 = new DataTable();
        DataTable dtplayer = new DataTable();
        DataTable dtplayer2 = new DataTable();  
        string query = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new MySqlConnection("Server = localhost; uid = root; pwd=isbmantap; database=premier_league");

            try
            {
                conn.Open();
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            try
            {
                query = "select team_name, team_id from team";
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt);

                cb_Team.DataSource = dt;
                cb_Team.ValueMember = "team_id";
                cb_Team.DisplayMember = "team_name";

                query = $"select player_id, player_name from player";
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dtplayer2);

                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cb_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dt2.Clear();
            try
            {
                query = $"select p.player_id, p.team_number, p.player_name, p.nationality_id, p.playing_pos, p.height, p.weight, p.birthdate, p.team_id from player p, team t where p.team_id = '{cb_Team.SelectedValue}'";
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt2);
                dgv_team.DataSource = dt2;

                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cb_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            dt2.Clear();
            try
            {
                query = $"select p.player_name, d.match_id, d.minute, d.team_id, d.player_id, d.type from `dmatch` d LEFT JOIN player p on d.player_id = '{cb_player.SelectedValue}'";
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt2);
                dgv_team.DataSource = dt2;

                cb_player.DataSource = dt2;
                cb_player.ValueMember = "team_id";
                cb_player.DisplayMember = "player_name";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
