﻿namespace TH14S2_0706022310037
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tb_MatchID = new System.Windows.Forms.TextBox();
            this.dgv_1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_TeamHome = new System.Windows.Forms.ComboBox();
            this.cb_TeamAway = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_Team = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_Player = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_Type = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_ADD = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_INSERT = new System.Windows.Forms.Button();
            this.DTP_MatchDate = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_Minute = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Match ID";
            // 
            // tb_MatchID
            // 
            this.tb_MatchID.Location = new System.Drawing.Point(124, 34);
            this.tb_MatchID.Name = "tb_MatchID";
            this.tb_MatchID.Size = new System.Drawing.Size(144, 22);
            this.tb_MatchID.TabIndex = 1;
            // 
            // dgv_1
            // 
            this.dgv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_1.Location = new System.Drawing.Point(38, 129);
            this.dgv_1.Name = "dgv_1";
            this.dgv_1.RowHeadersWidth = 51;
            this.dgv_1.RowTemplate.Height = 24;
            this.dgv_1.Size = new System.Drawing.Size(477, 226);
            this.dgv_1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Team Home";
            // 
            // cb_TeamHome
            // 
            this.cb_TeamHome.FormattingEnabled = true;
            this.cb_TeamHome.Location = new System.Drawing.Point(124, 80);
            this.cb_TeamHome.Name = "cb_TeamHome";
            this.cb_TeamHome.Size = new System.Drawing.Size(143, 24);
            this.cb_TeamHome.TabIndex = 4;
            this.cb_TeamHome.SelectedIndexChanged += new System.EventHandler(this.cb_TeamHome_SelectedIndexChanged);
            // 
            // cb_TeamAway
            // 
            this.cb_TeamAway.FormattingEnabled = true;
            this.cb_TeamAway.Location = new System.Drawing.Point(564, 80);
            this.cb_TeamAway.Name = "cb_TeamAway";
            this.cb_TeamAway.Size = new System.Drawing.Size(143, 24);
            this.cb_TeamAway.TabIndex = 6;
            this.cb_TeamAway.SelectedIndexChanged += new System.EventHandler(this.cb_TeamAway_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(479, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Team Away";
            // 
            // cb_Team
            // 
            this.cb_Team.FormattingEnabled = true;
            this.cb_Team.Location = new System.Drawing.Point(598, 192);
            this.cb_Team.Name = "cb_Team";
            this.cb_Team.Size = new System.Drawing.Size(143, 24);
            this.cb_Team.TabIndex = 8;
            this.cb_Team.SelectedIndexChanged += new System.EventHandler(this.cb_Team_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(535, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Team ";
            // 
            // cb_Player
            // 
            this.cb_Player.FormattingEnabled = true;
            this.cb_Player.Location = new System.Drawing.Point(598, 237);
            this.cb_Player.Name = "cb_Player";
            this.cb_Player.Size = new System.Drawing.Size(143, 24);
            this.cb_Player.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(535, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Player";
            // 
            // cb_Type
            // 
            this.cb_Type.FormattingEnabled = true;
            this.cb_Type.Items.AddRange(new object[] {
            "CR",
            "CY",
            "GO",
            "GR",
            "GW",
            "PM"});
            this.cb_Type.Location = new System.Drawing.Point(598, 284);
            this.cb_Type.Name = "cb_Type";
            this.cb_Type.Size = new System.Drawing.Size(143, 24);
            this.cb_Type.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(535, 287);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Type";
            // 
            // btn_ADD
            // 
            this.btn_ADD.Location = new System.Drawing.Point(534, 326);
            this.btn_ADD.Name = "btn_ADD";
            this.btn_ADD.Size = new System.Drawing.Size(101, 29);
            this.btn_ADD.TabIndex = 13;
            this.btn_ADD.Text = "ADD";
            this.btn_ADD.UseVisualStyleBackColor = true;
            this.btn_ADD.Click += new System.EventHandler(this.btn_ADD_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(657, 326);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(101, 29);
            this.btn_Delete.TabIndex = 14;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_INSERT
            // 
            this.btn_INSERT.Location = new System.Drawing.Point(349, 376);
            this.btn_INSERT.Name = "btn_INSERT";
            this.btn_INSERT.Size = new System.Drawing.Size(185, 35);
            this.btn_INSERT.TabIndex = 15;
            this.btn_INSERT.Text = "INSERT";
            this.btn_INSERT.UseVisualStyleBackColor = true;
            this.btn_INSERT.Click += new System.EventHandler(this.btn_INSERT_Click);
            // 
            // DTP_MatchDate
            // 
            this.DTP_MatchDate.Location = new System.Drawing.Point(564, 29);
            this.DTP_MatchDate.Name = "DTP_MatchDate";
            this.DTP_MatchDate.Size = new System.Drawing.Size(248, 22);
            this.DTP_MatchDate.TabIndex = 16;
            this.DTP_MatchDate.ValueChanged += new System.EventHandler(this.DTP_MatchDate_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(479, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 16);
            this.label7.TabIndex = 17;
            this.label7.Text = "Match Date";
            // 
            // tb_Minute
            // 
            this.tb_Minute.Location = new System.Drawing.Point(598, 149);
            this.tb_Minute.Name = "tb_Minute";
            this.tb_Minute.Size = new System.Drawing.Size(143, 22);
            this.tb_Minute.TabIndex = 19;
            this.tb_Minute.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Minute_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(535, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 16);
            this.label8.TabIndex = 18;
            this.label8.Text = "Minute";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 430);
            this.Controls.Add(this.tb_Minute);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.DTP_MatchDate);
            this.Controls.Add(this.btn_INSERT);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_ADD);
            this.Controls.Add(this.cb_Type);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cb_Player);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cb_Team);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cb_TeamAway);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cb_TeamHome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgv_1);
            this.Controls.Add(this.tb_MatchID);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_MatchID;
        private System.Windows.Forms.DataGridView dgv_1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_TeamHome;
        private System.Windows.Forms.ComboBox cb_TeamAway;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_Team;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_Player;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_Type;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_ADD;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_INSERT;
        private System.Windows.Forms.DateTimePicker DTP_MatchDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_Minute;
        private System.Windows.Forms.Label label8;
    }
}

