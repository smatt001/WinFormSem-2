﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TH14S2_0706022310037
{
    public partial class Form1 : Form
    {
        MySqlConnection connect;
        MySqlCommand command;
        MySqlDataAdapter adapter;

        DataTable dgvdata = new DataTable();
        DataTable dmatchdata = new DataTable();
        DataTable dtHome = new DataTable();
        DataTable dtAway = new DataTable();
        DataTable dtType = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable LastTanggal = new DataTable();
        DataTable dt = new DataTable();
        DataTable MatchID = new DataTable();

        string query = "";
        string Year = "";
        string Month = "";
        string Day = "";

        int MatchCount = 0;
        int Last= 0;
        int Pilih = 0;
        int HomeCount = 0;
        int AwayCount = 0;

        public Form1()
        {
            InitializeComponent();
            tb_MatchID.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                connect = new MySqlConnection("server = localhost; uid = root; pwd = MySQLISBUC2024Sean; database = premier_league");
                connect.Open();
                query = "SELECT * From Team";
                command = new MySqlCommand(query, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtHome);
                adapter.Fill(dtAway);

                query = "select * from `dmatch`";
                command = new MySqlCommand(query, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtType);

                connect.Close();

                cb_TeamHome.DataSource = dtHome;
                cb_TeamHome.DisplayMember = "team_name";
                cb_TeamHome.ValueMember = "team_id";
                cb_TeamHome.Text = "";

                cb_TeamAway.DataSource = dtAway;
                cb_TeamAway.DisplayMember = "team_name";
                cb_TeamAway.ValueMember = "team_id";
                cb_TeamAway.Text = "";

                cb_Team.DataSource = dtHome;
                cb_Team.DisplayMember = "team_name";
                cb_Team.ValueMember = "team_id";

                dgvdata.Columns.Add("Team");
                dgvdata.Columns.Add("Player");
                dgvdata.Columns.Add("Type");
                dgv_1.DataSource = dgvdata;

                dmatchdata.Columns.Add("Minute");
                dmatchdata.Columns.Add("team_id");
                dmatchdata.Columns.Add("player_id");
                dmatchdata.Columns.Add("Type");
                cb_Team.Text = "";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btn_INSERT_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb_MatchID.Text != "")
                {
                    for (int i = 0; i < dgvdata.Rows.Count; i++)
                    {
                        query = $"INSERT INTO DMatch VALUES ('{tb_MatchID.Text}', '{dmatchdata.Rows[i][0]}', '{dmatchdata.Rows[i][1]}', '{dmatchdata.Rows[i][2]}', '{dmatchdata.Rows[i][3]}', '0');";
                        connect.Open();
                        command = new MySqlCommand(query, connect);
                        command.ExecuteNonQuery();
                        connect.Close();
                    }

                    query = $"INSERT INTO `match` VALUES ('{tb_MatchID.Text}', '{Year}-{Month}-{Day}', '{cb_TeamHome.SelectedValue}', '{cb_TeamAway.SelectedValue}', '{HomeCount}', '{AwayCount}', 'M002', '0');";
                    connect.Open();
                    command = new MySqlCommand(query, connect);
                    command.ExecuteNonQuery();
                    connect.Close();

                    cb_TeamAway.Text = "";
                    cb_TeamHome.Text = "";
                    tb_Minute.Text = "";
                    cb_Type.Text = "";
                    cb_Team.Text = "";
                    cb_Player.Text = "";
                    tb_MatchID.Text = "";

                    dgvdata.Rows.Clear();
                    dmatchdata.Rows.Clear();
                    AwayCount = 0;
                    HomeCount = 0;

                }
                else
                {
                    MessageBox.Show("Fill all the fields!", "ERROR");
                }
            }
            
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btn_ADD_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb_Minute.Text == "" || cb_Team.Text == "" || cb_Player.Text == "" || cb_Type.Text == "" || tb_MatchID.Text == "")
                {
                    MessageBox.Show("Bang, Masi Kosong bang");
                }
                else
                {
                    dgvdata.Rows.Add(cb_Team.Text, cb_Player.Text, cb_Type.Text);
                    if (cb_Type.Text == "GO" || cb_Type.Text == "GP")
                    {
                        if (cb_TeamAway.Text == cb_Team.Text)
                        {
                            AwayCount++;
                        }
                        else
                        {
                            HomeCount++;
                        }
                    }
                    if (cb_Type.Text == "GW")
                    {
                        if (cb_TeamAway.Text == cb_Team.Text)
                        {
                            HomeCount++;
                        }
                        else
                        {
                            AwayCount++;
                        }
                    }
                    dmatchdata.Rows.Add(tb_Minute.Text, cb_Team.SelectedValue, cb_Player.SelectedValue, cb_Type.Text);
                    tb_MatchID.Clear();
                    tb_Minute.Clear();
                    cb_Type.SelectedIndex = 0;
                    cb_Team.SelectedIndex = 0;
                    cb_Player.SelectedIndex = 0;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if(dgv_1.Rows.Count > 0)
                {
                    dgv_1.Rows.RemoveAt(dgv_1.SelectedRows[0].Index);
                    if (cb_Type.Text == "GO" || cb_Type.Text == "GP")
                    {
                        if (cb_TeamAway.Text == cb_Team.Text)
                        {
                            AwayCount--;
                        }
                        else
                        {
                            HomeCount--;
                        }
                    }
                    if (cb_Type.Text == "GW")
                    {
                        if (cb_TeamAway.Text == cb_Team.Text)
                        {
                            HomeCount--;
                        }
                        else
                        {
                            AwayCount--;
                        }
                    }
                }
                
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void cb_TeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cb_TeamHome.Text == cb_TeamAway.Text)
                {
                    MessageBox.Show("Cannot Pick The same team");
                }
                else
                {
                    dt = new DataTable();
                    query = $"SELECT team_name, team_id FROM team WHERE team_id = '{cb_TeamHome.SelectedValue}' or team_id = '{cb_TeamAway.SelectedValue}'";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dt);

                    cb_Team.ValueMember = "team_id";
                    cb_Team.DisplayMember = "team_name";
                    cb_Team.DataSource = dt;
                    cb_Team.Text = "";
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void cb_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cb_TeamAway.Text == cb_TeamHome.Text)
                {
                    MessageBox.Show("Cannot Pick the Same team");
                }
                else
                {
                    dt = new DataTable();
                    query = $"SELECT team_name, team_id FROM team WHERE team_id = '{cb_TeamHome.SelectedValue}' or team_id = '{cb_TeamAway.SelectedValue}'";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dt);

                    cb_Team.ValueMember = "team_id";
                    cb_Team.DisplayMember = "team_name";
                    cb_Team.DataSource = dt;
                    cb_Team.Text = "";
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            
        }

        private void DTP_MatchDate_ValueChanged(object sender, EventArgs e)
        {
            
            try
            {
                query = $"SELECT concat(date_format(match_date, '%Y'), date_format(match_date, '%m'), date_format(match_Date, '%d')) FROM `match` ORDER BY 1 desc LIMIT 1";
                command = new MySqlCommand(query, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(LastTanggal);

                Year = DTP_MatchDate.Value.Year.ToString();
                Month = DTP_MatchDate.Value.Month.ToString();
                Day = DTP_MatchDate.Value.Day.ToString();

                if (Convert.ToInt32(Month) < 10)
                {
                    Month = "0" + Month;
                }
                if (Convert.ToInt32(Day) < 10)
                {
                    Month = "0" + Day;
                }
                Pilih = Convert.ToInt32(Year + Month + Day);
                Last = Convert.ToInt32(LastTanggal.Rows[0][0]);

                if (Pilih < Last)
                {
                    MessageBox.Show("Date Picked Cannot be earlier than the last match");
                }
                else
                {
                    query = $"SELECT match_id FROM `match` WHERE match_id like '{Year}%' ORDER BY 1 desc LIMIT 1 ";
                    command = new MySqlCommand(query, connect);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(MatchID);

                    if (MatchID.Rows.Count == 0)
                    {
                        tb_MatchID.Text = Year + "001";
                    }
                    else if (MatchID.Rows.Count == 1)
                    {
                        MatchCount = Convert.ToInt32(MatchID.Rows[0][0]) + 1;
                        tb_MatchID.Text = MatchCount.ToString();
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void tb_Minute_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void cb_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_Team.Text != "")
            {
                dtPlayer = new DataTable();
                query = $"SELECT p.player_name, p.player_id from player p, team t where t.team_id = '{cb_Team.SelectedValue}'";
                command = new MySqlCommand(query, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtPlayer);

                cb_Player.ValueMember = "player_id";
                cb_Player.DisplayMember = "player_name";
                cb_Player.DataSource = dtPlayer;
                cb_Player.Text = "";
            }
        }
    }
}
